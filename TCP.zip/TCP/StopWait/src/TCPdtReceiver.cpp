
#include "Global.h"
#include "TCPdtReceiver.h"


SRRdtReceiver::SRRdtReceiver(): expectSequenceNumberRcvd(0)
{
    if((fp=fopen("window2.txt","w"))==NULL)
    {
        printf("file cannot open \n");
        exit(0);
    }
    for(int i=0;i<4;i++)
    {
        this->expectSequenceNumberRcvd.push_back(i);      // 期望接收的序号
        this->visited.push_back(false);
    }
    this->AckPkt.acknum = -1; //初始状态下，上次发送的确认包的确认序号为-1，使得当第一个接受的数据包出错时该确认报文的确认号为-1
    this->AckPkt.checksum = 0;
    this->AckPkt.seqnum = -1;	//忽略该字段
    for(int j = 0; j < Configuration::PAYLOAD_SIZE;j++){
        this->AckPkt.payload[j] = '.';
    }
    this->AckPkt.checksum = pUtils->calculateCheckSum(this->AckPkt);
}


SRRdtReceiver::~SRRdtReceiver()
{
    fclose(fp);
}

void SRRdtReceiver::PrintWindow() {
    printf("接收方接收窗口为:[");
    fprintf(fp, "接收方接收窗口为:[");
    for(int i=0;i<this->expectSequenceNumberRcvd.size();i++)
    {
        printf("%d",this->expectSequenceNumberRcvd[i]);
        fprintf(fp, "%d",this->expectSequenceNumberRcvd[i]);
        if(this->visited[i]==true)
        {
            printf("/1");
            fprintf(fp, "/1");
        }
        else
        {
            printf("/0");
            fprintf(fp, "/0");
        }
        if(i<this->expectSequenceNumberRcvd.size()-1)
        {
            printf(" ");
            fprintf(fp, " ");
        }
    }
    printf("]\n");
    fprintf(fp, "]\n");
}

void SRRdtReceiver::receive(const Packet &packet) {
	//检查校验和是否正确
	int checkSum = pUtils->calculateCheckSum(packet);
	if(checkSum == packet.checksum)             //如果校验和正确
    {
	    int tag=0;
	    for(int i=0;i<4;i++)
        {
	        if(this->expectSequenceNumberRcvd[i] == packet.seqnum&&!visited[i])   //接收到的序号在期望窗口内&&接收方无该缓存
            {
	            tag=1;
               
                fprintf(fp,"接收方正确收到发送方的报文%d\n",packet.seqnum);
                pUtils->printPacket("接收方正确收到发送方的报文", packet);
                this->Pkt.push_back(packet);                   //接收方将这个包缓存
                this->visited[i]=true;                              //分组标记为已接收
                PrintWindow();
                break;
            }
        }
	    while(this->visited[0])
        {
	        visited.erase(visited.begin());
	        visited.push_back(false);
	        for(int i=0;i<this->Pkt.size();i++)
            {
	            if(this->Pkt[i].seqnum==this->expectSequenceNumberRcvd[0])
                {
                    // 取出Message，向上递交给应用层
                    Message msg;
                    memcpy(msg.data, this->Pkt[i].payload, sizeof(this->Pkt[i].payload));
                    this->Pkt.erase(this->Pkt.begin()+i);
                    pns->delivertoAppLayer(RECEIVER, msg);
                    this->expectSequenceNumberRcvd.erase(this->expectSequenceNumberRcvd.begin());
                    int length=this->expectSequenceNumberRcvd.size();
                    this->expectSequenceNumberRcvd.push_back((this->expectSequenceNumberRcvd[length-1]+1)%8);
                    break;
                }
            }
        }
        this->AckPkt.acknum=this->expectSequenceNumberRcvd[0];
        this->AckPkt.checksum=pUtils->calculateCheckSum(this->AckPkt);
        if(tag==1)
        {
            pUtils->printPacket("接收方发送确认报文", this->AckPkt);
            fprintf(fp,"接收方发送确认报文ack=%d\n",this->AckPkt.acknum);
        }
        pns->sendToNetworkLayer(SENDER, this->AckPkt);	//调用模拟网络环境的sendToNetworkLayer，通过网络层发送确认报文到对方
    }
	else {
		if (checkSum != packet.checksum) {
			pUtils->printPacket("接收方没有正确收到发送方的报文,数据校验错误", packet);
		}
	}
}
