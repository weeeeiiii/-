
#include "Global.h"
#include "SRRdtSender.h"
int sum[10000]={0};
SRRdtSender::SRRdtSender(): expectSequenceNumberSend(0), waitingState(false)
{
    if((fp=fopen("window.txt","w"))==NULL)
    {
        printf("file cannot open \n");
        exit(0);
    }
}

SRRdtSender::~SRRdtSender()
{
    fclose(fp);
}

bool SRRdtSender::getWaitingState() {
    if(this->packetWaitingAck.size()>=4)
    {
        waitingState=true;
    }
    else
    {
        waitingState=false;
    }
	return waitingState;
}

void SRRdtSender::slid_window() {
    fprintf(fp, "当前发送窗口为:[");
    printf("当前发送窗口为:[");
    for(int i=0;i<this->packetWaitingAck.size();i++)
    {
        printf("%d",this->packetWaitingAck[i].seqnum);
        fprintf(fp, "%d",this->packetWaitingAck[i].seqnum);
        if(this->visited[i]==true)
        {
            printf("/1");
            fprintf(fp,"/1");
        }
        else
        {
            printf("/0");
            fprintf(fp,"/0");
        }
        if(i<this->packetWaitingAck.size()-1){
            printf(" ");
            fprintf(fp, " ");
        }
    }
    printf("]\n");
    fprintf(fp, "]\n");
}

bool SRRdtSender::send(const Message &message) {
	if (this->waitingState) { //发送方处于等待确认状态
		return false;
	}

	Packet temp;
	temp.acknum=-1;
	temp.seqnum=this->expectSequenceNumberSend;
	temp.checksum=0;
    memcpy(temp.payload, message.data, sizeof(message.data));
    temp.checksum = pUtils->calculateCheckSum(temp);
    pUtils->printPacket("发送方发送报文", temp);
    pns->stopTimer(SENDER,this->expectSequenceNumberSend);				//首先关闭定时器
    pns->startTimer(SENDER, Configuration::TIME_OUT,this->expectSequenceNumberSend);	//启动发送方定时器
    pns->sendToNetworkLayer(RECEIVER, temp);								//调用模拟网络环境的sendToNetworkLayer，通过网络层发送到对方
    this->packetWaitingAck.push_back(temp);
    this->visited.push_back(false);
    this->expectSequenceNumberSend=(this->expectSequenceNumberSend+1)%8;
    slid_window();
    return true;
}

void SRRdtSender::receive(const Packet &ackPkt) {
    //检查校验和是否正确
    int checkSum = pUtils->calculateCheckSum(ackPkt);

    for(int i=0;i<this->packetWaitingAck.size();i++)
    {
        //如果校验和正确，并且确认序号=发送方已发送并等待确认的数据包序号
        if (checkSum == ackPkt.checksum && ackPkt.acknum == this->packetWaitingAck[i].seqnum) {
            pUtils->printPacket("发送方正确收到确认", ackPkt);
            fprintf(fp, "发送方正确收到确认ack=%d\n",ackPkt.acknum);
            this->visited[i]=true;
            while(this->visited.size()>0&&this->visited[0])
            {
                pns->stopTimer(SENDER,this->packetWaitingAck[0].seqnum);		//首先关闭定时器
                this->visited.erase(this->visited.begin());
                this->packetWaitingAck.erase((this->packetWaitingAck.begin()));
            }
            slid_window();
            break;
        }
    }
}

void SRRdtSender::timeoutHandler(int seqNum) {
	pns->stopTimer(SENDER,seqNum);										//首先关闭定时器
	for(int i=0;i<this->packetWaitingAck.size();i++)
    {
	    if(this->packetWaitingAck[i].seqnum==seqNum)
        {
            pUtils->printPacket("发送方定时器时间到，重发上次发送的报文", this->packetWaitingAck[i]);
            pns->sendToNetworkLayer(RECEIVER, this->packetWaitingAck[i]);			//重新发送数据包
            break;
        }
    }
    pns->startTimer(SENDER, Configuration::TIME_OUT,seqNum);			//重新启动发送方定时器
}
