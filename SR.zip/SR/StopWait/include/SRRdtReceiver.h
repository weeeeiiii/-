#ifndef STOP_WAIT_RDT_RECEIVER_H
#define STOP_WAIT_RDT_RECEIVER_H
#include "RdtReceiver.h"
#include <vector>
class SRRdtReceiver : public RdtReceiver
{
private:
	vector<int> expectSequenceNumberRcvd;	// 期待收到的下一个报文序号
	Packet AckPkt;		                //发送的确认报文
	vector<Packet> Pkt;                 //缓存的报文
	vector<bool> visited;           //用来标记是否接收过
	FILE *fp;
public:
	SRRdtReceiver();
	virtual ~SRRdtReceiver();
    virtual void PrintWindow();

public:
	void receive(const Packet &packet);	//接收报文，将被NetworkService调用
};

#endif

