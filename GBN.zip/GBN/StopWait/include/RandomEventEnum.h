#ifndef RANDOM_EVENT_ENUM_H
#define RANDOM_EVENT_ENUM_H



/* 定义随机事件的目标*/
enum  RandomEventTarget {
	SENDER,							//数据发送方
	RECEIVER						//数据接收方
};

#endif